import Main from "main"
import Box from "box"
new Main(canvas);
